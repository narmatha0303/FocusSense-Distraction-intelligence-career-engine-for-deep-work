// --- Core Logic ---

function updateClock() {
  const now = new Date();
  const h = now.getHours().toString().padStart(2, '0');
  const m = now.getMinutes().toString().padStart(2, '0');
  const clockEl = document.getElementById('clock');
  if (clockEl) clockEl.textContent = `${h}:${m}`;

  const dateEl = document.getElementById('date');
  if (dateEl) {
    const options = { weekday: 'long', month: 'long', day: 'numeric' };
    dateEl.textContent = now.toLocaleDateString(undefined, options);
  }

  // Update greeting
  const greetingEl = document.getElementById('greeting');
  if (greetingEl) {
    let period = "Morning";
    if (now.getHours() >= 12 && now.getHours() < 17) period = "Afternoon";
    if (now.getHours() >= 17) period = "Evening";
    
    if (!chrome.runtime?.id) return;
    chrome.storage.local.get("focussense_user_name", (data) => {
      if (chrome.runtime.lastError) return;
      const name = data.focussense_user_name || "Developer";
      greetingEl.textContent = `Good ${period}, ${name}`;
    });
  }
}

// --- Focus System ---

async function initFocus() {
  const input = document.getElementById('focus-input');
  const display = document.getElementById('focus-display');
  const prompt = document.getElementById('focus-prompt');
  if (!input || !display) return;

  const today = new Date().toDateString();
  if (!chrome.runtime?.id) return;
  const data = await chrome.storage.local.get("focussense_daily_focus");
  const focusData = data.focussense_daily_focus || {};

  if (focusData.date === today && focusData.text) {
    showFocus(focusData.text);
  }

  input.addEventListener('keypress', async (e) => {
    if (e.key === 'Enter' && input.value.trim()) {
      const text = input.value.trim();
      await chrome.storage.local.set({ "focussense_daily_focus": { date: today, text } });
      showFocus(text);
    }
  });

  display.addEventListener('click', () => {
    display.style.display = 'none';
    input.style.display = 'block';
    prompt.style.display = 'block';
    input.focus();
  });

  function showFocus(text) {
    display.textContent = text;
    display.style.display = 'block';
    input.style.display = 'none';
    prompt.textContent = "Your main focus for today:";
  }
}

function initNav() {
  const dashBtn = document.getElementById('open-dashboard');
  const settingsBtn = document.getElementById('open-settings');
  const settingsModal = document.getElementById('settings-modal');
  const closeSettings = document.getElementById('close-settings');

  if (dashBtn) {
    dashBtn.onclick = () => {
      chrome.tabs.create({ url: chrome.runtime.getURL("dashboard/dashboard.html") });
    };
  }

  if (settingsBtn && settingsModal) {
    settingsBtn.onclick = () => {
      settingsModal.style.display = 'flex';
    };
  }

  if (closeSettings && settingsModal) {
    closeSettings.onclick = () => {
      settingsModal.style.display = 'none';
    };
  }
}

// Rendering functions removed for minimal UI. Everything is now in the Dashboard.

// --- Settings & Customization ---

async function initSettings() {
  const nameInput = document.getElementById('user-name-input');
  const wallInput = document.getElementById('wallpaper-input');
  const fileInput = document.getElementById('wallpaper-file');
  const saveBtn = document.getElementById('save-settings');

  if (!chrome.runtime?.id) return;
  const DEFAULT_WALLPAPER = "https://images.unsplash.com/photo-1477346611705-65d1883cee1e?auto=format&fit=crop&q=80&w=2850";

  const data = await chrome.storage.local.get(["focussense_user_name", "focussense_wallpaper"]);
  if (nameInput) nameInput.value = data.focussense_user_name || "";
  if (wallInput) wallInput.value = data.focussense_wallpaper || "";

  const setWallpaper = (url) => {
    document.body.style.backgroundImage = `url(${url || DEFAULT_WALLPAPER})`;
    document.body.style.backgroundSize = "cover";
    document.body.style.backgroundPosition = "center";
  };

  setWallpaper(data.focussense_wallpaper);

  saveBtn.onclick = async () => {
    let newWall = wallInput.value.trim();
    const name = nameInput.value.trim();

    // Check for file upload first
    if (fileInput && fileInput.files && fileInput.files[0]) {
      const file = fileInput.files[0];
      const reader = new FileReader();
      
      reader.onload = async (e) => {
        const base64 = e.target.result;
        await chrome.storage.local.set({
          "focussense_user_name": name,
          "focussense_wallpaper": base64
        });
        setWallpaper(base64);
        alert("HD Wallpaper saved!");
      };
      
      reader.readAsDataURL(file); // Keep original quality
    } else {
      // Fallback to URL
      await chrome.storage.local.set({
        "focussense_user_name": name,
        "focussense_wallpaper": newWall
      });
      setWallpaper(newWall);
      alert("Preferences saved!");
    }
    updateClock(); // Refresh greeting
  };
}

// --- Init ---

document.addEventListener('DOMContentLoaded', () => {
  updateClock();
  setInterval(updateClock, 1000);
  initFocus();
  initNav();
  initSettings();
});

// --- Real-time Sync ---
chrome.storage.onChanged.addListener((changes) => {
  if (changes.focussense_daily_focus) {
    initFocus();
  }
  if (changes.focussense_todos) {
    renderTasks();
  }
  if (changes.focussense_reading) {
    renderReading();
  }
  if (changes.focussense_logs) {
    renderAnalytics();
  }
});

const DISTRACTING_SITES = [
  "youtube.com", "instagram.com", "twitter.com", "x.com", "facebook.com",
  "reddit.com", "linkedin.com", "netflix.com", "tiktok.com", "snapchat.com",
  "pinterest.com", "twitch.tv", "quora.com", "amazon.com", "ebay.com"
];

// --- Extension Icon Action ---
chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: chrome.runtime.getURL("dashboard/dashboard.html") });
});

const COOLDOWN_MS = 60 * 1000;

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.url && tab.url.startsWith("http")) {
    if (tab.incognito) {
      return;
    }

    try {
      const urlObj = new URL(tab.url);
      let hostname = urlObj.hostname.toLowerCase();
      if (hostname.startsWith("www.")) {
        hostname = hostname.substring(4);
      }

      const matchedSite = DISTRACTING_SITES.find(site => 
        hostname === site || hostname.endsWith("." + site)
      );

      if (matchedSite) {
        const data = await chrome.storage.local.get("focussense_logs");
        let logs = data.focussense_logs || [];
        const now = Date.now();

        // Check 60-second cooldown
        const lastLogForSite = [...logs].reverse().find(log => log.site === matchedSite);
        if (lastLogForSite && (now - lastLogForSite.timestamp) < COOLDOWN_MS) {
          return;
        }

        // Limit to 7 days
        const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;
        logs = logs.filter(l => (now - l.timestamp) < SEVEN_DAYS_MS);

        logs.push({
          site: matchedSite,
          timestamp: now
        });

        await chrome.storage.local.set({ "focussense_logs": logs });
      }
    } catch (error) {
      console.error("Error processing tab URL:", error);
    }
  }
});

chrome.commands.onCommand.addListener(async (command) => {
  if (command === "capture-content") {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab || !tab.id || !tab.url || !tab.url.startsWith("http")) {
        console.warn("Cannot capture from this page (non-http)");
        return;
      }

      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          const selectedText = window.getSelection().toString().trim();
          const data = {
            text: selectedText || document.title || "Untitled Insight",
            url: window.location.href,
            timestamp: Date.now()
          };
          return data;
        }
      });

      if (results && results[0] && results[0].result) {
        const capture = results[0].result;
        const data = await chrome.storage.local.get("focussense_captures");
        const captures = data.focussense_captures || [];
        
        captures.push(capture);
        const limitedCaptures = captures.slice(-50); // Store more insights
        await chrome.storage.local.set({ "focussense_captures": limitedCaptures });

        // Feedback to user
        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: (msg) => {
            const div = document.createElement('div');
            div.textContent = `🎯 Insight Captured: ${msg}`;
            div.style.cssText = "position:fixed; top:20px; right:20px; background:#6c63ff; color:white; padding:12px 20px; border-radius:8px; z-index:999999; font-family:sans-serif; box-shadow:0 4px 12px rgba(0,0,0,0.2); transition: opacity 0.5s;";
            document.body.appendChild(div);
            setTimeout(() => { div.style.opacity = '0'; setTimeout(() => div.remove(), 500); }, 2000);
          },
          args: [capture.text.substring(0, 30) + "..."]
        });
      }
    } catch (error) {
      console.error("Error capturing content:", error);
    }
  }
});

// --- Active Protection for Focus Mode ---
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status === "loading" && tab.url && tab.url.startsWith("http")) {
    const data = await chrome.storage.local.get("focussense_focus_state");
    const focusState = data.focussense_focus_state;

    if (focusState && focusState.active) {
      const urlObj = new URL(tab.url);
      let hostname = urlObj.hostname.toLowerCase();
      if (hostname.startsWith("www.")) hostname = hostname.substring(4);

      const isDistracting = DISTRACTING_SITES.some(site => 
        hostname === site || hostname.endsWith("." + site)
      );

      if (isDistracting) {
        chrome.tabs.remove(tabId);
        // Optional: show notification if we had permission, but for now just close
      }
    }
  }
});

// --- Module 4: Tab Limiter ---
chrome.tabs.onCreated.addListener(async () => {
  const settings = await chrome.storage.local.get("focussense_settings");
  if (settings.focussense_settings?.tabLimiterEnabled) {
    const maxTabs = settings.focussense_settings.maxTabs || 10;
    const tabs = await chrome.tabs.query({ windowType: 'normal' });
    if (tabs.length > maxTabs) {
      // Create notification if possible, or just close newest tab
      const newestTab = tabs.sort((a, b) => b.id - a.id)[0];
      if (newestTab) {
        chrome.tabs.remove(newestTab.id);
        // Simple alert via injected script if possible, but background can't alert easily.
        // We'll rely on the dashboard to show status.
      }
    }
  }
});

// --- Module 5: Site Time Tracker ---
let activeTabId = null;
let startTime = Date.now();
let activeSite = null;

async function updateTime() {
  if (activeSite) {
    const elapsed = Math.round((Date.now() - startTime) / 1000); // seconds
    const data = await chrome.storage.local.get("focussense_time");
    const timeData = data.focussense_time || {};
    const today = new Date().toISOString().split('T')[0];
    
    if (!timeData[today]) timeData[today] = {};
    timeData[today][activeSite] = (timeData[today][activeSite] || 0) + elapsed;
    
    await chrome.storage.local.set({ "focussense_time": timeData });
    startTime = Date.now();
  }
}

chrome.tabs.onActivated.addListener(async (activeInfo) => {
  await updateTime();
  const tab = await chrome.tabs.get(activeInfo.tabId);
  if (tab.url && tab.url.startsWith("http")) {
    const urlObj = new URL(tab.url);
    activeSite = urlObj.hostname.replace("www.", "");
    startTime = Date.now();
  } else {
    activeSite = null;
  }
});

chrome.windows.onFocusChanged.addListener(async (windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    await updateTime();
    activeSite = null;
  } else {
    const [tab] = await chrome.tabs.query({ active: true, windowId: windowId });
    if (tab && tab.url && tab.url.startsWith("http")) {
      const urlObj = new URL(tab.url);
      activeSite = urlObj.hostname.replace("www.", "");
      startTime = Date.now();
    }
  }
});

chrome.idle.onStateChanged.addListener(async (state) => {
  if (state !== "active") {
    await updateTime();
    activeSite = null;
  }
});

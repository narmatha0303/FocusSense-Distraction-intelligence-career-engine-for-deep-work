import { getDailyQuestion } from '../data/questions.js';

// --- Analytics Engine ---

function getTodayLogs(logs) {
  if (!logs) return [];
  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  return logs.filter(log => log.timestamp >= startOfToday);
}

function getTotalToday(logs) {
  return getTodayLogs(logs).length;
}

function getMostDistractingSite(logs) {
  if (!logs || logs.length === 0) return null;

  const counts = {};
  const lastVisit = {};
  
  logs.forEach(log => {
    counts[log.site] = (counts[log.site] || 0) + 1;
    lastVisit[log.site] = Math.max(lastVisit[log.site] || 0, log.timestamp);
  });

  let mostFrequent = null;
  let maxCount = 0;

  for (const site in counts) {
    if (counts[site] > maxCount) {
      maxCount = counts[site];
      mostFrequent = site;
    } else if (counts[site] === maxCount && maxCount > 0) {
      if (lastVisit[site] > lastVisit[mostFrequent]) {
        mostFrequent = site;
      }
    }
  }

  return mostFrequent;
}

function getPeakHour(logs) {
  if (!logs || logs.length === 0) return null;

  const hourCounts = new Array(24).fill(0);
  logs.forEach(log => {
    const hour = new Date(log.timestamp).getHours();
    hourCounts[hour]++;
  });

  let peakHour = 0;
  let maxCount = 0;
  for (let i = 0; i < 24; i++) {
    if (hourCounts[i] > maxCount) {
      maxCount = hourCounts[i];
      peakHour = i;
    }
  }
  
  if (maxCount === 0) return null;

  const ampm = peakHour >= 12 ? 'PM' : 'AM';
  const displayHour = peakHour % 12 || 12;
  return `${displayHour} ${ampm}`;
}

function getDailyBreakdown(logs) {
  const breakdown = [];
  const now = new Date();
  
  for (let i = 6; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    const dateStr = d.toDateString();
    
    const count = logs.filter(log => new Date(log.timestamp).toDateString() === dateStr).length;
    breakdown.push({ day: dateStr.split(' ')[0] + ' ' + dateStr.split(' ')[2], count });
  }
  
  return breakdown;
}

function getHourlyBreakdown(logs) {
  const breakdown = [];
  const hourCounts = new Array(24).fill(0);
  
  if (logs) {
    logs.forEach(log => {
      const hour = new Date(log.timestamp).getHours();
      hourCounts[hour]++;
    });
  }

  for (let i = 0; i < 24; i++) {
    breakdown.push({ hour: i, count: hourCounts[i] });
  }

  return breakdown;
}

function getSiteCounts(logs) {
  const counts = {};
  if (!logs) return [];
  
  logs.forEach(log => {
    counts[log.site] = (counts[log.site] || 0) + 1;
  });

  const siteCounts = [];
  for (const site in counts) {
    siteCounts.push({ site: site, count: counts[site] });
  }

  siteCounts.sort((a, b) => b.count - a.count);
  return siteCounts;
}

// --- Toolkit Modules ---

async function initLinkVault(filter = "") {
  const container = document.getElementById('link-vault-list');
  const saveBtn = document.getElementById('save-current-link');
  if (!container || !saveBtn) return;

  const renderLinks = (links) => {
    let filtered = links;
    if (filter) {
      filtered = links.filter(l => l.title.toLowerCase().includes(filter.toLowerCase()) || l.url.toLowerCase().includes(filter.toLowerCase()));
    }
    
    container.innerHTML = filtered.length ? '' : `<li class="toolkit-item" style="color:var(--text-secondary); font-size:12px;">${filter ? 'No links match' : 'No links saved'}</li>`;
    [...filtered].reverse().slice(0, 5).forEach((link, index) => {
      const li = document.createElement('li');
      li.className = 'toolkit-item';
      li.innerHTML = `
        <span class="text" style="font-size:12px;"><a href="${link.url}" target="_blank" style="color:inherit;text-decoration:none">${link.title}</a></span>
        <button class="btn" style="background:transparent;border:none;color:var(--error);padding:0" data-index="${links.indexOf(link)}">×</button>
      `;
      const delBtn = li.querySelector('button');
      if (delBtn) {
        delBtn.onclick = async (e) => {
          const idx = parseInt(e.currentTarget.dataset.index);
          links.splice(idx, 1);
          await chrome.storage.local.set({ "focussense_links": links });
          renderLinks(links);
        };
      }
      container.appendChild(li);
    });
  };

  const data = await chrome.storage.local.get("focussense_links");
  let links = data.focussense_links || [];
  renderLinks(links);
  
  // Only bind once
  if (!saveBtn.dataset.bound) {
    saveBtn.onclick = async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && tab.url && tab.url.startsWith("http")) {
        links.push({ title: tab.title, url: tab.url, timestamp: Date.now() });
        await chrome.storage.local.set({ "focussense_links": links });
        renderLinks(links);
      }
    };
    saveBtn.dataset.bound = "true";
  }
}

async function initReadingList(filter = "") {
  const container = document.getElementById('reading-list-items');
  const input = document.getElementById('reading-input');
  const addBtn = document.getElementById('add-reading');
  if (!container || !input || !addBtn) return;

  const renderItems = (items) => {
    let filtered = items;
    if (filter) {
      filtered = items.filter(i => i.title.toLowerCase().includes(filter.toLowerCase()));
    }

    container.innerHTML = filtered.length ? '' : `<li class="toolkit-item" style="color:var(--text-secondary)">${filter ? 'No items match' : 'List empty'}</li>`;
    [...filtered].reverse().slice(0, 10).forEach((item, index) => {
      const actualIndex = items.indexOf(item);
      const li = document.createElement('li');
      li.className = `toolkit-item ${item.read ? 'read' : ''}`;
      li.innerHTML = `
        <input type="checkbox" ${item.read ? 'checked' : ''}>
        <span class="text">${item.title}</span>
        <button class="btn" style="background:transparent;border:none;color:var(--error);padding:0" data-index="${actualIndex}">×</button>
      `;
      
      const check = li.querySelector('input');
      if (check) {
        check.onchange = async (e) => {
          items[actualIndex].read = e.target.checked;
          await chrome.storage.local.set({ "focussense_reading": items });
          renderItems(items);
        };
      }

      const del = li.querySelector('button');
      if (del) {
        del.onclick = async (e) => {
          items.splice(actualIndex, 1);
          await chrome.storage.local.set({ "focussense_reading": items });
          renderItems(items);
        };
      }
      
      container.appendChild(li);
    });
  };

  const data = await chrome.storage.local.get("focussense_reading");
  let items = data.focussense_reading || [];
  renderItems(items);

  if (!addBtn.dataset.bound) {
    addBtn.onclick = async () => {
      if (input.value.trim()) {
        items.push({ title: input.value.trim(), read: false, timestamp: Date.now() });
        await chrome.storage.local.set({ "focussense_reading": items });
        input.value = '';
        renderItems(items);
      }
    };
    addBtn.dataset.bound = "true";
  }
}

async function initQuickNotes() {
  const textarea = document.getElementById('quick-notes');
  if (!textarea) return;
  const data = await chrome.storage.local.get("focussense_notes");
  textarea.value = data.focussense_notes || '';

  let timeout;
  textarea.oninput = () => {
    clearTimeout(timeout);
    timeout = setTimeout(async () => {
      await chrome.storage.local.set({ "focussense_notes": textarea.value });
    }, 500);
  };
}

async function initTimeTracker() {
  const container = document.getElementById('time-tracker-list');
  if (!container) return;
  const data = await chrome.storage.local.get("focussense_time");
  const today = new Date().toISOString().split('T')[0];
  const timeData = data.focussense_time?.[today] || {};

  const sortedSites = Object.entries(timeData)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 3);

  container.innerHTML = sortedSites.length ? '' : '<p style="color:var(--text-secondary);font-size:13px">No activity tracked today</p>';
  
  sortedSites.forEach(([site, seconds]) => {
    const mins = Math.round(seconds / 60);
    const div = document.createElement('div');
    div.style.display = 'flex';
    div.style.justifyContent = 'space-between';
    div.style.fontSize = '13px';
    div.style.marginBottom = '8px';
    div.innerHTML = `<span style="color:var(--text-primary)">${site}</span><span style="color:var(--accent)">${mins}m</span>`;
    container.appendChild(div);
  });
}

async function initGratitudeLog() {
  const inputs = document.querySelectorAll('.gratitude-input');
  const saveBtn = document.getElementById('save-gratitude');
  const streakEl = document.getElementById('gratitude-streak');
  if (!saveBtn || !streakEl) return;

  const updateStreak = (log) => {
    if (!log || log.length === 0) return;
    const dates = [...new Set(log.map(e => new Date(e.timestamp).toDateString()))].reverse();
    let streak = 0;
    const curr = new Date();
    
    for (let i = 0; i < dates.length; i++) {
      const d = new Date(dates[i]);
      const diff = Math.floor((curr - d) / (1000 * 60 * 60 * 24));
      if (diff <= i + 1) streak++;
      else break;
    }
    streakEl.innerText = `Streak: ${streak}🔥`;
  };

  const data = await chrome.storage.local.get("focussense_gratitude");
  const log = data.focussense_gratitude || [];
  updateStreak(log);

  saveBtn.onclick = async () => {
    const entries = Array.from(inputs).map(i => i.value.trim()).filter(v => v);
    if (entries.length > 0) {
      log.push({ entries, timestamp: Date.now() });
      await chrome.storage.local.set({ "focussense_gratitude": log });
      updateStreak(log);
      inputs.forEach(i => i.value = '');
      saveBtn.innerText = "Saved!";
      setTimeout(() => saveBtn.innerText = "Log Gratitude", 2000);
    }
  };
}

async function initTabLimiterSettings() {
  const toggle = document.getElementById('tab-limiter-toggle');
  const maxInput = document.getElementById('max-tabs-input');
  const targetInput = document.getElementById('daily-target-input');
  if (!toggle || !maxInput || !targetInput) return;

  const data = await chrome.storage.local.get("focussense_settings");
  const settings = data.focussense_settings || { tabLimiterEnabled: false, maxTabs: 10, dailyTarget: 15 };

  toggle.checked = settings.tabLimiterEnabled;
  maxInput.value = settings.maxTabs;
  targetInput.value = settings.dailyTarget || 15;

  const saveSettings = async () => {
    const newSettings = {
      tabLimiterEnabled: toggle.checked,
      maxTabs: parseInt(maxInput.value) || 10,
      dailyTarget: parseInt(targetInput.value) || 15
    };
    await chrome.storage.local.set({ "focussense_settings": newSettings });
    renderAnalytics(); // Refresh progress bar
  };

  toggle.onchange = saveSettings;
  maxInput.onchange = saveSettings;
  targetInput.onchange = saveSettings;
}

// --- Main Dashboard Logic ---

// Update renderAnalytics to accept range
async function renderAnalytics(filter = "", daysRange = 7) {
  const data = await chrome.storage.local.get(["focussense_logs", "focussense_settings"]);
  let logs = data.focussense_logs || [];
  const settings = data.focussense_settings || { maxTabs: 10, dailyTarget: 15 };

  console.log(`[Analyst] Total logs in storage: ${logs.length}`);

  // Apply Date Range Filter
  const now = new Date();
  const nowTs = now.getTime();
  
  const msInDay = 24 * 60 * 60 * 1000;
  
  if (daysRange === 1) {
    // "Today" should be from start of calendar day
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    logs = logs.filter(l => l.timestamp >= startOfToday);
  } else {
    logs = logs.filter(l => (nowTs - l.timestamp) < (daysRange * msInDay));
  }

  console.log(`[Analyst] Filtered logs for ${daysRange} day(s): ${logs.length}`);
  const totalFiltered = logs.length;
  
  // Calculate specific "Today" metrics for KPIs regardless of range
  const totalToday = getTotalToday(data.focussense_logs || []);

  // 1. Productivity Score
  const score = Math.max(0, 100 - (totalToday * 5));
  const scoreEl = document.getElementById('productivity-score');
  if (scoreEl) {
    scoreEl.textContent = `${score}%`;
    scoreEl.style.color = score > 80 ? 'var(--success)' : score > 50 ? 'var(--warning)' : 'var(--error)';
  }

  // 2. Trend Analysis (Always compare today vs 7-day average for context)
  const last7DaysLogs = (data.focussense_logs || []).filter(l => (nowTs - l.timestamp) < (7 * msInDay));
  const dailyAverage = last7DaysLogs.length / 7;
  
  const trendEl = document.getElementById('distraction-trend');
  const indicatorEl = document.getElementById('trend-indicator');
  if (trendEl && indicatorEl) {
    trendEl.textContent = dailyAverage.toFixed(1);
    const diff = totalToday - dailyAverage;
    if (diff < 0) {
      indicatorEl.textContent = `📉 ${Math.abs(diff).toFixed(1)} below avg`;
      indicatorEl.style.color = 'var(--success)';
    } else {
      indicatorEl.textContent = `📈 ${diff.toFixed(1)} above avg`;
      indicatorEl.style.color = 'var(--error)';
    }
  }
  
  const dashTotal = document.getElementById('total');
  if (dashTotal) dashTotal.textContent = totalFiltered;

  // Behavioral Insights based on FILTERED logs
  const mostDistractingSite = getMostDistractingSite(logs);
  const peakHourStr = getPeakHour(logs);
  const patternEl = document.getElementById('insight-pattern');
  const impactEl = document.getElementById('insight-impact');
  const adviceEl = document.getElementById('insight-advice');
  
  if (patternEl && adviceEl && impactEl) {
    patternEl.textContent = `Focus leak detected at ${peakHourStr || 'variable hours'} primarily via ${mostDistractingSite || 'unidentified nodes'}.`;
    const timeLost = totalFiltered * 5;
    impactEl.textContent = `Estimated ${timeLost}m lost over selected period. Average intensity: ${totalFiltered > (daysRange * 10) ? 'High' : 'Optimal'}.`;
    adviceEl.textContent = totalFiltered > (daysRange * 10) ? "Immediate Action: Deploy 'Focus Mode' during peak identified hours." : "Maintenance: System stability detected. Continue current discipline.";
  }

  // Heatmap Rendering (Uses filtered logs)
  const heatmapContainer = document.getElementById('heatmap-container');
  if (heatmapContainer) {
    heatmapContainer.innerHTML = '';
    const breakdown = getHourlyBreakdown(logs);
    const maxCount = Math.max(...breakdown.map(b => b.count));

    breakdown.forEach(b => {
      const cell = document.createElement('div');
      cell.className = 'heatmap-cell';
      let level = 0;
      if (b.count > 0) {
        if (b.count === maxCount) level = 4;
        else if (b.count > maxCount * 0.7) level = 3;
        else if (b.count > maxCount * 0.4) level = 2;
        else level = 1;
      }
      cell.classList.add(`level-${level}`);
      const ampm = b.hour >= 12 ? 'p' : 'a';
      const displayHour = b.hour % 12 || 12;
      cell.innerHTML = `<span class="hour-label">${displayHour}${ampm}</span><span class="count-label">${b.count > 0 ? b.count : ''}</span>`;
      heatmapContainer.appendChild(cell);
    });
  }

  // Table rendering (Uses filtered logs)
  const tableBody = document.getElementById('site-table-body');
  if (tableBody) {
    let siteCounts = getSiteCounts(logs);
    if (filter) siteCounts = siteCounts.filter(s => s.site.toLowerCase().includes(filter.toLowerCase()));
    tableBody.innerHTML = siteCounts.length ? '' : `<tr><td colspan="2" class="empty-state">${filter ? 'No sites match search' : 'No sites tracked yet'}</td></tr>`;
    siteCounts.slice(0, 10).forEach(s => {
      const tr = document.createElement('tr');
      if (s.site === mostDistractingSite) tr.classList.add('highlight-row');
      tr.innerHTML = `<td>${s.site}</td><td>${s.count}</td>`;
      tableBody.appendChild(tr);
    });
  }
}

async function renderCaptures(filter = "") {
  const data = await chrome.storage.local.get("focussense_captures");
  let captures = data.focussense_captures || [];
  const grid = document.getElementById('captures-grid');
  if (!grid) return;

  if (filter) {
    captures = captures.filter(c => c.text.toLowerCase().includes(filter.toLowerCase()) || c.url.toLowerCase().includes(filter.toLowerCase()));
  }

  grid.innerHTML = captures.length ? '' : `<div class="empty-state">${filter ? 'No insights match search' : 'No insights captured'}</div>`;
  [...captures].sort((a, b) => b.timestamp - a.timestamp).slice(0, 10).forEach(c => {
    const card = document.createElement('div');
    card.className = 'capture-card';
    card.innerHTML = `
      <div class="capture-text">${c.text}</div>
      <a href="${c.url}" class="capture-url" target="_blank">${c.url.substring(0, 30)}...</a>
      <div class="capture-time">${new Date(c.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</div>
    `;
    grid.appendChild(card);
  });
}

async function initDashboard() {
  // Seed Mock Data if empty (Bring back the "old data" look)
  const existingData = await chrome.storage.local.get(["focussense_reading", "focussense_links", "focussense_logs"]);
  
  if (!existingData.focussense_reading || existingData.focussense_reading.length === 0) {
    await chrome.storage.local.set({ "focussense_reading": [
      { title: "Deep Work by Cal Newport", read: false, timestamp: Date.now() },
      { title: "Atomic Habits - Productivity Guide", read: true, timestamp: Date.now() },
      { title: "The Psychology of Focus", read: false, timestamp: Date.now() }
    ]});
  }

  if (!existingData.focussense_links || existingData.focussense_links.length === 0) {
    await chrome.storage.local.set({ "focussense_links": [
      { title: "Google Analytics Console", url: "https://analytics.google.com", timestamp: Date.now() },
      { title: "Stack Overflow - SQL Help", url: "https://stackoverflow.com", timestamp: Date.now() },
      { title: "Project Roadmap 2024", url: "https://trello.com", timestamp: Date.now() }
    ]});
  }

  if (!existingData.focussense_logs || existingData.focussense_logs.length === 0) {
    const now = Date.now();
    const mockLogs = [];
    // Generate some distractions for today
    for(let i=0; i<15; i++) {
      mockLogs.push({
        timestamp: now - (Math.random() * 8 * 3600 * 1000), // Last 8 hours
        url: "https://youtube.com",
        title: "Entertainment"
      });
    }
    await chrome.storage.local.set({ "focussense_logs": mockLogs });
  }

  try {
    const updateView = async () => {
      const range = 1; // Default to Today
      const grouping = 'hourly'; // Default to Hourly View
      
      await renderAnalytics("", range);
      await renderCharts(range, grouping);
      await renderCaptures();
    };

    await updateView();

    // Consolidated Global Search Implementation
    const searchInput = document.getElementById('global-search');
    if (searchInput) {
      let debounceSearch;
      searchInput.oninput = (e) => {
        const query = e.target.value.toLowerCase().trim();
        clearTimeout(debounceSearch);
        debounceSearch = setTimeout(async () => {
          const range = 1;
          const grouping = 'hourly';
          
          // Analyst Dashboard Update
          await renderAnalytics(query, range);
          await renderCharts(range, grouping);
          await renderCaptures(query);
          
          // Toolkit Components Update
          if (typeof initReadingList === 'function') initReadingList(query);
          if (typeof initLinkVault === 'function') initLinkVault(query);
        }, 300);
      };
    }

    // Toolkit Initialization
    await initLinkVault();
    await initReadingList();
    await initQuickNotes();
    await initTimeTracker();
    await initGratitudeLog();
    await initTabLimiterSettings();
    await initFocusTimer();
    
    // Wallpaper Sync
    const settingsData = await chrome.storage.local.get("focussense_wallpaper");
    const DEFAULT_WALLPAPER = "https://images.unsplash.com/photo-1477346611705-65d1883cee1e?auto=format&fit=crop&q=80&w=2850";
    document.body.style.backgroundImage = `url(${settingsData.focussense_wallpaper || DEFAULT_WALLPAPER})`;

    // Daily Question
    const dailyQ = getDailyQuestion();
    const badgeEl = document.getElementById('dash-badge');
    const questionEl = document.getElementById('dash-question');
    const answerEl = document.getElementById('dash-answer');
    const toggleBtnEl = document.getElementById('dash-toggle-btn');

    if (badgeEl) badgeEl.textContent = dailyQ.category;
    if (questionEl) questionEl.textContent = dailyQ.question;
    if (answerEl) answerEl.textContent = dailyQ.answer;
    
    if (toggleBtnEl && answerEl) {
      toggleBtnEl.onclick = () => {
        const isVisible = answerEl.classList.toggle('visible');
        toggleBtnEl.textContent = isVisible ? 'Hide Answer' : 'Show Answer';
      };
    }

  } catch (error) {
    console.error("Dashboard init error:", error);
  }
}

async function initFocusTimer() {
  const display = document.getElementById('focus-timer-display');
  const startBtn = document.getElementById('start-focus');
  const cancelBtn = document.getElementById('cancel-focus');
  const statsEl = document.getElementById('focus-stats');
  if (!display || !startBtn || !cancelBtn) return;

  let timerInterval;

  const updateDisplay = (seconds) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    display.textContent = `${m}:${s.toString().padStart(2, '0')}`;
  };

  const renderStats = async () => {
    const data = await chrome.storage.local.get("focussense_focus_sessions");
    const sessions = data.focussense_focus_sessions || [];
    const today = new Date().toDateString();
    const todaySessions = sessions.filter(s => new Date(s.timestamp).toDateString() === today);
    const totalMinutes = todaySessions.length * 25;
    statsEl.textContent = todaySessions.length > 0 
      ? `Completed today: ${todaySessions.length} (${totalMinutes}m deep work)`
      : "No sessions today";
  };

  const startTimer = async (durationSeconds) => {
    const endTime = Date.now() + (durationSeconds * 1000);
    await chrome.storage.local.set({ "focussense_focus_state": { active: true, endTime } });
    runTimer(endTime);
  };

  const runTimer = (endTime) => {
    clearInterval(timerInterval);
    startBtn.disabled = true;
    startBtn.textContent = "Focusing...";
    
    timerInterval = setInterval(async () => {
      const remaining = Math.round((endTime - Date.now()) / 1000);
      if (remaining <= 0) {
        clearInterval(timerInterval);
        await completeSession();
      } else {
        updateDisplay(remaining);
      }
    }, 1000);
  };

  const completeSession = async () => {
    const data = await chrome.storage.local.get("focussense_focus_sessions");
    const sessions = data.focussense_focus_sessions || [];
    sessions.push({ timestamp: Date.now(), duration: 25 });
    await chrome.storage.local.set({ 
      "focussense_focus_sessions": sessions,
      "focussense_focus_state": { active: false }
    });
    
    display.textContent = "DONE!";
    startBtn.disabled = false;
    startBtn.textContent = "Start Focus";
    renderStats();
    alert("Focus session complete! Take a break.");
  };

  const cancelTimer = async () => {
    clearInterval(timerInterval);
    await chrome.storage.local.set({ "focussense_focus_state": { active: false } });
    display.textContent = "25:00";
    startBtn.disabled = false;
    startBtn.textContent = "Start Focus";
  };

  // Check initial state
  const data = await chrome.storage.local.get("focussense_focus_state");
  const state = data.focussense_focus_state;
  if (state && state.active && state.endTime > Date.now()) {
    runTimer(state.endTime);
  }

  startBtn.onclick = () => startTimer(25 * 60);
  cancelBtn.onclick = cancelTimer;
  renderStats();
}

// --- Charting ---

let trendChart, distroChart;

// Update renderCharts to accept range and grouping
async function renderCharts(daysRange = 7, grouping = 'daily') {
  if (typeof Chart === 'undefined') return;

  const data = await chrome.storage.local.get("focussense_logs");
  let logs = data.focussense_logs || [];
  
  const now = new Date();
  const nowTs = now.getTime();

  const msInDay = 24 * 60 * 60 * 1000;

  if (daysRange === 1) {
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    logs = logs.filter(l => l.timestamp >= startOfToday);
  } else {
    logs = logs.filter(l => (nowTs - l.timestamp) < (daysRange * msInDay));
  }

  console.log(`[Charts] Rendering ${grouping} view for ${logs.length} data points.`);

  let chartLabels, chartData;

  if (grouping === 'hourly') {
    const breakdown = getHourlyBreakdown(logs);
    chartLabels = breakdown.map(b => `${b.hour % 12 || 12}${b.hour >= 12 ? 'pm' : 'am'}`);
    chartData = breakdown.map(b => b.count);
  } else {
    const breakdown = [];
    for (let i = daysRange - 1; i >= 0; i--) {
      const d = new Date(nowTs - (i * msInDay));
      const dateStr = d.toDateString();
      const count = logs.filter(log => new Date(log.timestamp).toDateString() === dateStr).length;
      breakdown.push({ label: dateStr.split(' ')[0] + ' ' + dateStr.split(' ')[2], count });
    }
    chartLabels = breakdown.map(b => b.label);
    chartData = breakdown.map(b => b.count);
  }

  const ctxTrend = document.getElementById('trendChart');
  const ctxDistro = document.getElementById('distroChart');
  if (!ctxTrend || !ctxDistro) return;

  if (trendChart) trendChart.destroy();
  if (distroChart) distroChart.destroy();

  trendChart = new Chart(ctxTrend, {
    type: 'line',
    data: {
      labels: chartLabels,
      datasets: [{
        label: 'Distractions',
        data: chartData,
        borderColor: '#6c63ff',
        backgroundColor: 'rgba(108, 99, 255, 0.1)',
        borderWidth: 3,
        tension: 0.4,
        fill: true,
        pointRadius: 5
      }]
    },
    options: { 
      responsive: true, 
      plugins: { legend: { display: false } },
      scales: {
        y: { beginAtZero: true, grid: { color: 'rgba(255,255,255,0.05)' } },
        x: { grid: { display: false } }
      }
    }
  });

  const siteCounts = getSiteCounts(logs).slice(0, 5);
  distroChart = new Chart(ctxDistro, {
    type: 'doughnut',
    data: {
      labels: siteCounts.map(s => s.site),
      datasets: [{
        data: siteCounts.map(s => s.count),
        backgroundColor: ['#6c63ff', '#38bdf8', '#22c55e', '#f59e0b', '#ef4444'],
        borderWidth: 0
      }]
    },
    options: { responsive: true, cutout: '70%', plugins: { legend: { position: 'right' } } }
  });
}

document.addEventListener('DOMContentLoaded', initDashboard);

// --- Real-time Sync ---
chrome.storage.onChanged.addListener((changes) => {
  if (changes.focussense_logs) {
    // Default to Today/Hourly view on real-time update
    renderAnalytics("", 1);
    renderCharts(1, 'hourly');
  }
});

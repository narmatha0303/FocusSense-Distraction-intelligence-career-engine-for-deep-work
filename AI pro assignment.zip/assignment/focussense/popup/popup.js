import { getDailyQuestion } from '../data/questions.js';

// --- Analytics Engine (Copied from dashboard.js) ---

function getTodayLogs(logs) {
  if (!logs) return [];
  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  return logs.filter(log => log.timestamp >= startOfToday);
}

function getTotalToday(logs) {
  return getTodayLogs(logs).length;
}

function getMostDistractingSite(logs) {
  const todayLogs = getTodayLogs(logs);
  if (todayLogs.length === 0) return null;

  const counts = {};
  const lastVisit = {};
  
  todayLogs.forEach(log => {
    counts[log.site] = (counts[log.site] || 0) + 1;
    lastVisit[log.site] = Math.max(lastVisit[log.site] || 0, log.timestamp);
  });

  let mostFrequent = null;
  let maxCount = 0;

  for (const site in counts) {
    if (counts[site] > maxCount) {
      maxCount = counts[site];
      mostFrequent = site;
    } else if (counts[site] === maxCount && maxCount > 0) {
      if (lastVisit[site] > lastVisit[mostFrequent]) {
        mostFrequent = site;
      }
    }
  }

  return mostFrequent;
}

function getPeakHour(logs) {
  const todayLogs = getTodayLogs(logs);
  if (todayLogs.length === 0) return null;

  const hourCounts = new Array(24).fill(0);
  todayLogs.forEach(log => {
    const hour = new Date(log.timestamp).getHours();
    hourCounts[hour]++;
  });

  let peakHour = 0;
  let maxCount = 0;
  for (let i = 0; i < 24; i++) {
    if (hourCounts[i] > maxCount) {
      maxCount = hourCounts[i];
      peakHour = i;
    }
  }
  
  if (maxCount === 0) return null;

  const ampm = peakHour >= 12 ? 'PM' : 'AM';
  const displayHour = peakHour % 12 || 12;
  return `${displayHour} ${ampm}`;
}

function generateInsights(logs) {
  const totalToday = getTotalToday(logs);
  const mostDistractingSite = getMostDistractingSite(logs);
  const peakHour = getPeakHour(logs);

  const insights = [];

  if (totalToday > 15) {
    insights.push(`High distraction day. Stay aware.`);
  } else if (totalToday === 0) {
    insights.push(`No distractions today. Good control.`);
  } else if (totalToday > 5) {
    insights.push(`You've visited distracting sites ${totalToday} times today. Worth keeping an eye on.`);
  } else {
    insights.push(`Only ${totalToday} distractions today. You're doing well — keep it up.`);
  }

  if (mostDistractingSite) {
    insights.push(`${mostDistractingSite} is your biggest distraction today.`);
  }

  if (peakHour) {
    insights.push(`Your focus drops most around ${peakHour}.`);
  }

  while (insights.length < 3) {
    if (totalToday === 0) {
      insights.push(`Stay locked in. You're doing great.`);
    } else {
      insights.push(`Keep observing your patterns — insights improve over time.`);
    }
  }

  return insights.slice(0, 3);
}

// --- Popup UI Logic ---

async function initPopup() {
  try {
    const data = await chrome.storage.local.get("focussense_logs");
    const logs = data.focussense_logs || [];

    // Render Section 1: Summary
    const totalToday = getTotalToday(logs);
    const mostDistractingSite = getMostDistractingSite(logs);
    const peakHour = getPeakHour(logs);

    document.getElementById('total-distractions').textContent = totalToday;
    document.getElementById('top-site').textContent = mostDistractingSite ? mostDistractingSite : '-';
    document.getElementById('peak-hour').textContent = peakHour ? peakHour : '—';

    // Render Section 2: Insights
    const insights = generateInsights(logs);
    document.getElementById('top-insight').textContent = insights[0];

    // Render Section 3: Daily Question
    const dailyQuestion = getDailyQuestion();
    document.getElementById('question-badge').textContent = dailyQuestion.category;
    document.getElementById('question-text').textContent = dailyQuestion.question;
    document.getElementById('answer-text').textContent = dailyQuestion.answer;

    const toggleBtn = document.getElementById('toggle-answer-btn');
    const answerText = document.getElementById('answer-text');

    toggleBtn.addEventListener('click', () => {
      const isVisible = answerText.classList.contains('visible');
      if (isVisible) {
        answerText.classList.remove('visible');
        toggleBtn.textContent = 'Show Answer';
      } else {
        answerText.classList.add('visible');
        toggleBtn.textContent = 'Hide Answer';
      }
    });

    // --- Module 1: Link Vault Quick Save ---
    const saveVaultBtn = document.getElementById('save-to-vault');
    saveVaultBtn.addEventListener('click', async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && tab.url.startsWith("http")) {
        const data = await chrome.storage.local.get("focussense_links");
        const links = data.focussense_links || [];
        links.push({ title: tab.title, url: tab.url, timestamp: Date.now() });
        await chrome.storage.local.set({ "focussense_links": links });
        saveVaultBtn.textContent = '✅ Saved to Vault';
        saveVaultBtn.style.background = 'var(--accent)';
        setTimeout(() => {
          saveVaultBtn.textContent = '🔖 Save Current Page to Vault';
          saveVaultBtn.style.background = '';
        }, 2000);
      }
    });

    // Render Footer Link
    document.getElementById('dashboard-link').addEventListener('click', () => {
      chrome.tabs.create({ url: chrome.runtime.getURL('dashboard/dashboard.html') });
    });

  } catch (error) {
    console.error("Error loading popup data:", error);
    document.getElementById('top-insight').textContent = "Error loading data. Please try again.";
  } finally {
    document.body.classList.add('loaded');
  }
}

// Since type="module" implies defer, the DOM is already parsed when this runs.
initPopup();

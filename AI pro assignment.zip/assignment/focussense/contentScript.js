// Logic to capture selected text or fallback to document title
(() => {
  const selectedText = window.getSelection().toString().trim();
  return {
    text: selectedText || document.title,
    url: window.location.href
  };
})();

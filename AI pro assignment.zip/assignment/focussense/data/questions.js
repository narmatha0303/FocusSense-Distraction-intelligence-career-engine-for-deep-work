export const QUESTIONS = [
  // SQL
  {
    id: 1,
    category: "SQL",
    question: "What is the difference between WHERE and HAVING in SQL?",
    answer: "WHERE filters rows before any grouping occurs (before the GROUP BY clause). HAVING filters aggregated data after the grouping has occurred."
  },
  {
    id: 2,
    category: "SQL",
    question: "Write a query to find the second-highest salary from an Employees table.",
    answer: "SELECT MAX(salary) FROM Employees WHERE salary < (SELECT MAX(salary) FROM Employees);"
  },
  {
    id: 3,
    category: "SQL",
    question: "What does a LEFT JOIN return that an INNER JOIN does not?",
    answer: "A LEFT JOIN returns all rows from the left table, and the matched rows from the right table. If there is no match, the result is NULL on the right side. An INNER JOIN only returns rows where there is a match in both tables."
  },
  {
    id: 4,
    category: "SQL",
    question: "What is a CTE (Common Table Expression)?",
    answer: "A CTE is a temporary named result set created using the WITH clause that you can reference within a SELECT, INSERT, UPDATE, or DELETE statement."
  },
  {
    id: 5,
    category: "SQL",
    question: "What is the difference between UNION and UNION ALL?",
    answer: "UNION combines the result sets of two or more SELECT statements and removes duplicates. UNION ALL does the same but keeps all duplicates, making it faster."
  },
  {
    id: 6,
    category: "SQL",
    question: "Explain the difference between a primary key and a foreign key.",
    answer: "A primary key uniquely identifies a record in a table. A foreign key is a field in one table that uniquely identifies a row of another table, establishing a relationship between them."
  },
  {
    id: 7,
    category: "SQL",
    question: "What are window functions in SQL?",
    answer: "Window functions perform calculations across a set of table rows that are somehow related to the current row, without collapsing them into a single output row like GROUP BY does (e.g., ROW_NUMBER(), RANK())."
  },
  {
    id: 8,
    category: "SQL",
    question: "How do you optimize a slow-running query?",
    answer: "Use EXPLAIN to analyze the execution plan, ensure proper indexing, avoid SELECT *, filter early using WHERE instead of HAVING, and minimize the use of subqueries in SELECT/WHERE clauses if joins are faster."
  },
  {
    id: 9,
    category: "SQL",
    question: "What is a self-join and when would you use it?",
    answer: "A self-join is a regular join where a table is joined to itself. It is used when you need to compare rows within the same table, like finding employees and their managers in the same Employees table."
  },
  {
    id: 10,
    category: "SQL",
    question: "Explain the difference between DELETE, TRUNCATE, and DROP.",
    answer: "DELETE removes rows one by one and can be rolled back. TRUNCATE removes all rows quickly but cannot be rolled back easily and resets identity columns. DROP completely removes the table structure from the database."
  },
  
  // Analytics
  {
    id: 11,
    category: "Analytics",
    question: "What is the difference between a metric and a dimension?",
    answer: "A metric is a quantitative measurement (e.g., revenue, user count). A dimension is a qualitative attribute used to categorize or segment metrics (e.g., country, device type)."
  },
  {
    id: 12,
    category: "Analytics",
    question: "How would you define and measure user retention?",
    answer: "Retention measures the percentage of users who return to a product after their initial visit. It's usually measured by taking cohorts of users who signed up in a period and tracking the percentage active in subsequent periods (e.g., Day 1, Day 7, Day 30 retention)."
  },
  {
    id: 13,
    category: "Analytics",
    question: "What is cohort analysis and when would you use it?",
    answer: "Cohort analysis breaks data into related groups (cohorts), usually by acquisition date. It's used to isolate user behavior over their lifecycle independent of overall growth trends."
  },
  {
    id: 14,
    category: "Analytics",
    question: "What is LTV (Customer Lifetime Value)?",
    answer: "LTV is the total revenue a business can reasonably expect from a single customer account throughout the business relationship. It's often calculated as (Average Order Value * Purchase Frequency) / Churn Rate."
  },
  {
    id: 15,
    category: "Analytics",
    question: "Explain the difference between mean and median, and when to use each.",
    answer: "The mean is the average value, while the median is the middle value when sorted. Use mean for normally distributed data, and median for skewed data or when outliers are present (like income)."
  },
  {
    id: 16,
    category: "Analytics",
    question: "What is Simpson's Paradox?",
    answer: "It's a phenomenon where a trend appears in several different groups of data but disappears or reverses when these groups are combined. It highlights the danger of omitted variable bias."
  },
  {
    id: 17,
    category: "Analytics",
    question: "How do you handle missing values in a dataset?",
    answer: "Depending on the context: drop the rows/columns if missingness is rare, impute using mean/median/mode, impute using predictive modeling, or flag them as a separate category if the missingness itself is informative."
  },
  {
    id: 18,
    category: "Analytics",
    question: "What is statistical significance?",
    answer: "It's a measure indicating that a result is likely not due to random chance. It is usually quantified by a p-value being less than a predetermined threshold (like 0.05)."
  },
  {
    id: 19,
    category: "Analytics",
    question: "What is a funnel analysis?",
    answer: "Funnel analysis tracks the drop-off rates of users as they move through a defined series of steps towards a goal (e.g., Signup -> Add to Cart -> Checkout)."
  },
  {
    id: 20,
    category: "Analytics",
    question: "What is the difference between correlation and causation?",
    answer: "Correlation means two variables move together. Causation means one variable actively causes the change in the other. Correlation does not imply causation (e.g., ice cream sales and shark attacks both rise in summer)."
  },

  // Case Study
  {
    id: 21,
    category: "Case Study",
    question: "Daily active users on your app dropped 20% overnight. How do you investigate?",
    answer: "1) Verify data pipeline/tracking isn't broken. 2) Segment by dimensions (platform, region, version) to isolate the drop. 3) Check for external factors (holidays, outages, competitor launches). 4) Check internal factors (recent deployments, marketing pauses)."
  },
  {
    id: 22,
    category: "Case Study",
    question: "Two A/B test variants show the same conversion rate but different revenue. What do you do?",
    answer: "Investigate the Average Order Value (AOV) and the types of products bought in each variant. One variant might be cannibalizing higher-priced items or pushing users toward cheaper items despite converting at the same rate."
  },
  {
    id: 23,
    category: "Case Study",
    question: "A stakeholder says 'our data is wrong.' How do you respond?",
    answer: "Don't get defensive. Ask for specific examples: 'Which dashboard/metric looks off, and what did you expect it to be?' Reproduce their query, check the upstream data lineage, and explain the methodology or find the bug."
  },
  {
    id: 24,
    category: "Case Study",
    question: "How would you evaluate the success of a newly launched feature?",
    answer: "Define success metrics beforehand (adoption rate, usage frequency, impact on core KPIs). Track feature usage over time, analyze the retention of users who use the feature vs. those who don't, and monitor for any negative impact on other metrics."
  },
  {
    id: 25,
    category: "Case Study",
    question: "The marketing team wants to double their ad spend. How do you advise them?",
    answer: "Analyze the Customer Acquisition Cost (CAC) and Lifetime Value (LTV) across different channels. Warn about diminishing returns (as you scale spend, CAC usually increases). Recommend scaling incrementally and monitoring marginal ROI."
  },
  {
    id: 26,
    category: "Case Study",
    question: "Engagement is up, but revenue is down. What's happening?",
    answer: "Users might be engaging with non-monetizable features (e.g., reading forums instead of buying). Check if high-value users churned while low-value users increased. Review pricing changes or discount code abuse."
  },
  {
    id: 27,
    category: "Case Study",
    question: "How do you decide what to A/B test next?",
    answer: "Prioritize based on potential impact and effort (ICE/RICE scoring). Look at funnel drop-offs for the biggest leaks. Interview users or look at heatmaps to identify friction points, then test hypotheses to solve them."
  },
  {
    id: 28,
    category: "Case Study",
    question: "You have 1 month of data showing a new subscription model works. Do you roll it out 100%?",
    answer: "Be cautious. 1 month might capture novelty effect or early adopters. It also doesn't show long-term churn. Depending on risk tolerance, either extend the test or do a phased rollout while monitoring long-term LTV."
  },
  {
    id: 29,
    category: "Case Study",
    question: "A new competitor launched with lower prices. How do we measure the impact?",
    answer: "Look for increases in churn rate, specifically stating 'competitor' as the reason if a survey exists. Monitor win/loss rates in sales. Track if brand search volume decreases while theirs increases."
  },
  {
    id: 30,
    category: "Case Study",
    question: "How would you design a dashboard for the CEO?",
    answer: "Keep it high-level. Focus on 3-5 'North Star' metrics (Revenue, Active Users, CAC, Churn). Include week-over-week or year-over-year comparisons. Avoid deep granular tables; use trend lines and clear red/green indicators for health."
  }
];

export function getDailyQuestion() {
  const index = Math.floor(Date.now() / 86400000) % QUESTIONS.length;
  return QUESTIONS[index];
}

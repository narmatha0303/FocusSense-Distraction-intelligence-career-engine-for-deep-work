# FocusSense – Distraction Intelligence + Career Engine
## Product Requirements Document (V1)

**Version:** 1.0  
**Type:** Chrome Extension  
**Audience:** This document is written to be handed off directly to an AI coding tool for step-by-step implementation.

---

## 1. Product Overview

### 1.1 What Is FocusSense?

FocusSense is a Chrome extension that silently observes browsing behavior, identifies distraction patterns, generates human-readable insights, and surfaces one Data Analyst skill-building question per day — all without blocking sites or requiring any login.

### 1.2 Design Philosophy

- **Observe, don't judge.** No site blocking in V1. The extension watches and reports.
- **Insights over raw data.** Numbers are converted into sentences that feel personal.
- **Minimal and fast.** The popup and dashboard must feel lightweight and load instantly.
- **Local and private.** All data lives in `chrome.storage.local`. Nothing leaves the device.

### 1.3 Target User

A developer, analyst, or knowledge worker who wants to understand their own distraction behavior and chip away at Data Analyst interview prep — without switching tools or breaking flow.

---

## 2. File Structure

Build the extension with the following file layout. Do not add files that aren't listed here.

```
focussense/
├── manifest.json
├── background.js
├── popup/
│   ├── popup.html
│   └── popup.js
├── dashboard/
│   ├── dashboard.html
│   └── dashboard.js
└── data/
    └── questions.js
```

---

## 3. Manifest

**File:** `manifest.json`

- Manifest version: 3
- Permissions required: `storage`, `tabs`, `activeTab`
- Host permissions: `<all_urls>`
- Background: service worker pointing to `background.js`
- Action: default popup pointing to `popup/popup.html`
- No content scripts needed

---

## 4. Distraction Site List

Define this list inside `background.js`. It must be easy to extend later.

```
youtube.com
instagram.com
twitter.com
x.com
facebook.com
reddit.com
linkedin.com
netflix.com
tiktok.com
snapchat.com
pinterest.com
twitch.tv
```

---

## 5. Data Model

All data is stored in `chrome.storage.local` under a single key: `focussense_logs`.

The value is an array of log entry objects. Each entry has exactly these fields:

```json
{
  "site": "youtube.com",
  "timestamp": 1718000000000
}
```

- `site`: the matched hostname from the distraction list (always lowercase, no subdomain prefix)
- `timestamp`: Unix milliseconds from `Date.now()`

No other fields. No nested objects. Keep it flat.

---

## 6. Background Service Worker

**File:** `background.js`

### 6.1 Trigger

Listen to `chrome.tabs.onUpdated`. Fire only when:
- `changeInfo.status === "complete"`
- The tab URL is a valid `http` or `https` URL

### 6.2 Logic

1. Parse the hostname from the tab URL.
2. Strip the `www.` prefix if present.
3. Check if the cleaned hostname matches any entry in the distraction list (exact match or `.endsWith(distractingSite)`).
4. If matched, load the existing log array from `chrome.storage.local`.
5. Push a new entry: `{ site: matchedSite, timestamp: Date.now() }`.
6. Save the updated array back to storage.

### 6.3 Constraints

- Do not log the same site more than once per 60-second window. Compare the last logged entry for that site before pushing.
- Handle the case where storage is empty (initialize to empty array).
- Do not log in incognito tabs (`tab.incognito === true`).

---

## 7. Analytics Engine

This is a set of pure functions. Write them in a separate section at the top of `dashboard.js` (and import/copy into `popup.js` as needed). They take the raw log array as input and return computed values.

### 7.1 `getTodayLogs(logs)`

Returns only entries where the timestamp falls within today's calendar date (midnight to now in local time).

### 7.2 `getTotalToday(logs)`

Returns the count of today's log entries as an integer.

### 7.3 `getMostDistractingSite(logs)`

Returns the hostname string that appears most frequently in today's logs. If there is a tie, return the one that was visited most recently. Returns `null` if no logs exist.

### 7.4 `getPeakHour(logs)`

Groups today's logs by hour (0–23). Returns the hour integer with the highest count. Returns `null` if no logs. Format for display as `"3 PM"` or `"10 AM"` using 12-hour format.

### 7.5 `getHourlyBreakdown(logs)`

Returns an array of 24 objects, one per hour:
```json
{ "hour": 14, "count": 3 }
```
Used to render the mini bar chart in the dashboard.

### 7.6 `getSiteCounts(logs)`

Returns an array of objects sorted descending by count:
```json
[{ "site": "youtube.com", "count": 7 }, ...]
```

---

## 8. Insight Generator

**File:** `dashboard.js` (and mirrored in `popup.js`)

Write a function `generateInsights(logs)` that takes today's logs and returns an array of up to 3 insight strings. Rules:

| Condition | Insight Text |
|---|---|
| totalToday >= 10 | `"You've been distracted {totalToday} times today. That's a lot — your focus is fragmented."` |
| totalToday >= 5 | `"You've visited distracting sites {totalToday} times today. Worth keeping an eye on."` |
| totalToday > 0 && totalToday < 5 | `"Only {totalToday} distractions today. You're doing well — keep it up."` |
| totalToday === 0 | `"Zero distractions logged today. Either you're in the zone, or just getting started."` |
| mostDistractingSite exists | `"Your biggest distraction today is {site}."` |
| peakHour exists | `"You tend to lose focus around {peakHour}. Consider protecting that hour."` |

Always return exactly 3 insights. If fewer conditions are met, pad with a neutral message like `"Keep observing your patterns — insights improve over time."`.

---

## 9. Daily Question Bank

**File:** `data/questions.js`

Export a JavaScript array called `QUESTIONS`. Each object has:

```js
{
  id: 1,
  category: "SQL",           // "SQL" | "Analytics" | "Case Study"
  question: "...",
  answer: "..."
}
```

Seed the file with exactly 30 questions: 10 SQL, 10 Analytics, 10 Case Study. Below are examples — fill in the rest with realistic interview-level content.

**SQL (examples):**
1. What is the difference between `WHERE` and `HAVING` in SQL?
2. Write a query to find the second-highest salary from an Employees table.
3. What does a `LEFT JOIN` return that an `INNER JOIN` does not?

**Analytics (examples):**
1. What is the difference between a metric and a dimension?
2. How would you define and measure user retention?
3. What is cohort analysis and when would you use it?

**Case Study (examples):**
1. Daily active users on your app dropped 20% overnight. How do you investigate?
2. Two A/B test variants show the same conversion rate but different revenue. What do you do?
3. A stakeholder says "our data is wrong." How do you respond?

### 9.1 Question Selection Logic

Write a function `getDailyQuestion()`:

1. Compute a day index: `Math.floor(Date.now() / 86400000) % QUESTIONS.length`
2. Return the question at that index.
3. This ensures the question changes every calendar day and cycles through all questions over time without any randomness.

---

## 10. Popup UI

**File:** `popup/popup.html` + `popup/popup.js`

### 10.1 Layout

The popup must be exactly **360px wide**. No scrolling. Single vertical column with three sections separated by thin dividers.

**Section 1 – Today's Summary**
- Heading: `"Today's Focus"`
- Stat line: `"{n} distractions"` in large text
- Sub-line: `"Most visited: {site}"` — show `"None yet"` if no data
- Sub-line: `"Peak hour: {hour}"` — show `"—"` if no data

**Section 2 – Top Insight**
- Show only the first insight string from `generateInsights()`
- Style it as a soft callout box (light background, subtle left border)

**Section 3 – Daily Question**
- Label: `"Today's Question"` + category badge (e.g., `SQL`, `Analytics`, `Case Study`)
- Question text in readable font
- A single button: `"Show Answer"`
- Answer text hidden by default; shown inline when button is clicked
- Button text changes to `"Hide Answer"` after reveal

**Footer link**
- Small text link: `"View Full Dashboard →"` that opens `dashboard/dashboard.html` in a new tab using `chrome.tabs.create()`

### 10.2 Behavior

- Load logs from `chrome.storage.local` on popup open
- Compute all stats fresh each time (no caching in popup)
- All rendering is done via vanilla JavaScript DOM manipulation — no frameworks

---

## 11. Dashboard Page

**File:** `dashboard/dashboard.html` + `dashboard/dashboard.js`

This is a full browser tab page, not a popup. It must look clean and intentional — like a minimal personal productivity tool.

### 11.1 Layout

Three sections on the page, stacked vertically with generous padding. Max content width: 720px, centered.

---

**Section 1: Distraction Summary**

Header: `"Distraction Summary — Today"`

Display a summary row with three stat cards:
- Card 1: Total distractions today (large number)
- Card 2: Most visited site
- Card 3: Peak distraction hour

Below the cards, render a simple **hourly bar chart**:
- 24 bars, one per hour (0–23)
- Bar height proportional to visit count for that hour
- Label x-axis with hours: `12a, 3a, 6a, 9a, 12p, 3p, 6p, 9p`
- Bars are purely HTML/CSS (no canvas, no SVG, no charting library)
- Highlight the peak hour bar in a distinct accent color
- If all counts are 0, show a message: `"No distractions logged yet today."`

Below the chart, show a table of all sites logged today with two columns: **Site** and **Visits**. Sort descending by visits.

---

**Section 2: Insights**

Header: `"What the Data Says"`

Display all 3 insights from `generateInsights()` as separate cards. Each card:
- Insight text
- A small icon or emoji prefix (💡 or similar)
- Subtle card styling (light background, border-radius, padding)

---

**Section 3: Daily Question**

Header: `"Daily Data Analyst Question"`

Same UI as the popup question section but wider and more spacious:
- Category badge
- Question text
- `"Show Answer"` button (toggle)
- Answer text revealed inline

Below the question, add a static line: `"Question {n} of 30 — refreshes daily"`

---

### 11.2 No Navigation, No Tabs

The dashboard is a single scrollable page. Do not add a sidebar, tabs, or any nav menu.

---

## 12. Styling Guidelines

Apply these rules consistently across popup and dashboard. No CSS framework. Pure CSS only.

| Token | Value |
|---|---|
| Background | `#0f1117` |
| Surface (cards) | `#1a1d27` |
| Border | `#2a2d3e` |
| Primary accent | `#6c63ff` |
| Text primary | `#e8e9f0` |
| Text secondary | `#8b8fa8` |
| Success green | `#22c55e` |
| Warning amber | `#f59e0b` |
| Font | System font stack: `-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif` |
| Border radius | `8px` for cards, `4px` for badges |
| Transition | `0.15s ease` for hover states |

The overall aesthetic must feel like a dark-mode developer tool — clean, dense, and functional. No gradients, no shadows, no decorative elements.

---

## 13. Build Phases

Implement the extension in exactly this order. Complete and verify each phase before starting the next.

---

### Phase 1: Core Tracking (No UI)

**Goal:** Silently log distractions to storage.

**Files to create:**
- `manifest.json`
- `background.js`

**Acceptance criteria:**
1. Load the extension in Chrome via `chrome://extensions` with Developer Mode on.
2. Visit `youtube.com`.
3. Open the Chrome DevTools console on the service worker (from the extensions page).
4. Run: `chrome.storage.local.get('focussense_logs', console.log)`
5. The result must contain at least one entry with `site: "youtube.com"` and a valid timestamp.
6. Visit the same site again within 60 seconds — confirm no duplicate entry is added.
7. Visit in an incognito tab — confirm nothing is logged.

---

### Phase 2: Analytics Functions

**Goal:** Pure JavaScript functions that compute all stats correctly.

**Files to create:**
- `dashboard/dashboard.js` (analytics section only — no DOM code yet)

**Acceptance criteria:**
1. Manually insert 10–15 fake log entries into `chrome.storage.local` covering different sites and hours.
2. Call each analytics function in the DevTools console.
3. `getTodayLogs()` returns only today's entries.
4. `getMostDistractingSite()` returns the correct top site.
5. `getPeakHour()` returns the correct peak hour formatted as `"X PM"`.
6. `getHourlyBreakdown()` returns an array of 24 objects.
7. `generateInsights()` returns exactly 3 non-empty strings.

---

### Phase 3: Popup UI

**Goal:** The popup opens and displays live data correctly.

**Files to create:**
- `popup/popup.html`
- `popup/popup.js`
- `data/questions.js` (needed for the daily question in the popup)

**Acceptance criteria:**
1. Click the extension icon — popup opens at exactly 360px width.
2. All three sections render without errors.
3. Stats reflect what's actually in storage (test with real browsing or injected data).
4. `"Show Answer"` button toggles correctly.
5. `"View Full Dashboard"` link opens a new tab to the dashboard page.
6. With zero logs, all fields show their empty-state values (no `undefined`, no blank spaces).

---

### Phase 4: Dashboard Page

**Goal:** Full dashboard renders correctly with all three sections.

**Files to create:**
- `dashboard/dashboard.html`
- Complete `dashboard/dashboard.js`

**Acceptance criteria:**
1. Open the dashboard from the popup link.
2. All three sections render with correct data from storage.
3. Hourly bar chart shows 24 bars. Peak bar is visually distinct.
4. Site table is sorted correctly.
5. All 3 insights render as separate cards.
6. Daily question shows and hides answer correctly.
7. With zero data, each section shows a clear empty-state message — no broken layout.

---

### Phase 5: Polish + Edge Cases

**Goal:** The extension handles all edge cases and feels solid.

**Checklist:**
- [ ] Popup loads in under 200ms on a machine with 500+ log entries in storage
- [ ] No `console.error` in background service worker during normal use
- [ ] Storage gracefully handles corrupt or missing data (wrap reads in try/catch)
- [ ] All empty states are handled: zero logs today, zero logs ever, only one site visited
- [ ] Extension icon does not break on any tab (chrome://, file://, etc.)
- [ ] Hourly chart bars never overflow their container regardless of count
- [ ] Answer text in question section wraps cleanly on long answers
- [ ] Test with all 12 sites in the distraction list — all are logged correctly

---

## 14. Out of Scope for V1

Do not implement any of the following. If an AI tool suggests adding these, reject them.

- Site blocking or redirect
- Login, accounts, or sync
- Any external API call
- AI-generated insights
- Charts using canvas, SVG, or a charting library
- Push notifications or badges
- Weekly/monthly history views
- Settings or configuration UI
- Export or import of data
- Multiple users or profiles

---

## 15. Future Considerations (V2 and Beyond)

These are captured here so V1 is not over-engineered to support them, but they are not forgotten.

- Weekly distraction trends with a 7-day sparkline
- A "focus session" mode: 25-minute timer that flags distractions during the session
- Smarter insight engine that detects patterns across multiple days (e.g., "You're consistently most distracted on Mondays")
- Ability to add/remove sites from the distraction list via a settings page
- Question quiz mode: mark questions as "known" or "needs review"
- Optional AI insight mode using the Anthropic API — send anonymized stats, receive a narrative insight

---

## 16. Glossary

| Term | Definition |
|---|---|
| Distraction log | A single record of visiting a tracked site, stored in `chrome.storage.local` |
| Peak hour | The clock hour (0–23) with the highest number of distraction events today |
| Insight | A human-readable sentence generated from computed stats |
| Daily question | One question from the 30-question bank, selected by date index |
| Surface | A card or container element in the UI |

---

*End of FocusSense V1 PRD*
